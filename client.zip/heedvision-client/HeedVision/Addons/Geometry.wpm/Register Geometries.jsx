import * as THREE from "three";
import { createTerrainGeometry } from "#Geometry .terrain"
import { createScatterGeometry } from "#Geometry .scatter"
if (globalThis["Geometry"]) delete globalThis["Geometry"];
globalThis["Geometry"] = {
    createTerrain: createTerrainGeometry,
    createScatter: createScatterGeometry,
    createGeometry: function (name) {
        switch (name) {
            case "Terrain":
                return createTerrainGeometry();
            case "Scatter":
                return createScatterGeometry();
            case "Sphere":
                return new THREE.SphereGeometry(1, 32, 32);
            default:
                throw new Error(`Geometry "${name}" is not registered.`);
        }
    },
}
//console.log("Registered Geometry");
window.addEventListener('beforeunload', () => { 
    delete globalThis["Geometry"] 
});