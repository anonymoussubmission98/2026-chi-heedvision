import * as THREE from "three";
const SCATTER_DATA = [
    {
        "id": 0,
        "x": -0.31209940704751515,
        "y": 1.7400262426579354,
        "z": 0.3987684750403151,
        "color": 6268127.950521468,
        "value": 14.653216471707708
    },
    {
        "id": 1,
        "x": 0.05132054059622204,
        "y": 0.9933486456912206,
        "z": 1.1961836523080471,
        "color": 8011135.593818002,
        "value": 34.21736812073238
    },
    {
        "id": 2,
        "x": 1.303474900844063,
        "y": -0.9396430120672794,
        "z": -0.7334023681513111,
        "color": 7141936.559939987,
        "value": 22.38225958893848
    },
    {
        "id": 3,
        "x": -0.9924068045074241,
        "y": -1.0380743655836078,
        "z": -1.0485304574793064,
        "color": 15417776.910782872,
        "value": 54.24044567593997
    },
    {
        "id": 4,
        "x": -0.2263273892940667,
        "y": -0.9825927125816531,
        "z": -1.7921232025606901,
        "color": 7208517.833477766,
        "value": 46.97318193283613
    },
    {
        "id": 5,
        "x": -1.2950252431884692,
        "y": -1.5737069582801704,
        "z": 0.8496739868367271,
        "color": 3892020.942152434,
        "value": 53.64840050851332
    },
    {
        "id": 6,
        "x": -1.4018723583735322,
        "y": 0.37406073673965956,
        "z": 0.9339676097833287,
        "color": 10752528.42272028,
        "value": 88.54014861819141
    },
    {
        "id": 7,
        "x": 1.916145675071475,
        "y": 0.03898649375536101,
        "z": 0.2944936342839761,
        "color": 2245224.2637680457,
        "value": 84.46850071914947
    },
    {
        "id": 8,
        "x": -1.9042501517137604,
        "y": 0.2969910150572086,
        "z": 0.8356004363965206,
        "color": 11594666.48517791,
        "value": 89.03840660967025
    },
    {
        "id": 9,
        "x": -0.306082130507515,
        "y": 1.4959179463642944,
        "z": -0.9711699745659845,
        "color": 16152551.85030893,
        "value": 71.80972101538349
    },
    {
        "id": 10,
        "x": -0.37161676290547563,
        "y": 0.7451150124966075,
        "z": -1.674956881750548,
        "color": 5210451.602624791,
        "value": 19.705824984446817
    },
    {
        "id": 11,
        "x": 1.4158681173471592,
        "y": -1.017087060903508,
        "z": 0.9751917610148659,
        "color": 7402441.437260108,
        "value": 58.66576846257679
    },
    {
        "id": 12,
        "x": 0.39538359561626324,
        "y": 0.18117595646347162,
        "z": 0.8786853159107837,
        "color": 7320802.28291413,
        "value": 67.35567108867379
    },
    {
        "id": 13,
        "x": 1.7237146808763697,
        "y": 1.0987308107931746,
        "z": -0.25855289502195467,
        "color": 10581683.43436564,
        "value": 13.572441634431998
    },
    {
        "id": 14,
        "x": 1.3763920587875464,
        "y": 1.8697076086040192,
        "z": 0.37980161596511053,
        "color": 9523135.421891375,
        "value": 61.843080414185955
    },
    {
        "id": 15,
        "x": -0.9681280607695761,
        "y": -0.5170381018834704,
        "z": 1.849887331063035,
        "color": 939117.2475041436,
        "value": 89.38974276660099
    },
    {
        "id": 16,
        "x": 0.7289973574628026,
        "y": 0.28694240781590175,
        "z": 1.117002478846603,
        "color": 13887682.225249812,
        "value": 34.22100856244725
    },
    {
        "id": 17,
        "x": -1.515355774259758,
        "y": -0.03686608888786047,
        "z": -1.3703902756378024,
        "color": 8686951.11811874,
        "value": 32.16030591031862
    },
    {
        "id": 18,
        "x": -1.596918197192033,
        "y": 1.4310238660347219,
        "z": 1.4006372019473918,
        "color": 2059580.106634603,
        "value": 73.44762658757958
    },
    {
        "id": 19,
        "x": -0.7041979105732508,
        "y": -1.198044363907576,
        "z": -1.975020229553528,
        "color": 8352686.109373952,
        "value": 34.97734253179877
    },
    {
        "id": 20,
        "x": 1.710087201641163,
        "y": -1.7419835841584237,
        "z": 0.19169113358346834,
        "color": 10933265.802050635,
        "value": 55.01232921456898
    },
    {
        "id": 21,
        "x": 1.4479565446652019,
        "y": 0.42702569658272393,
        "z": 0.015074146983584225,
        "color": 14157600.684635837,
        "value": 71.15154186397746
    },
    {
        "id": 22,
        "x": -1.576540251762721,
        "y": 1.9336849879255453,
        "z": 1.6221265923819628,
        "color": 4420976.481756663,
        "value": 56.94411049538146
    },
    {
        "id": 23,
        "x": -1.330212130340887,
        "y": 0.6372414004573619,
        "z": -1.2106687117958592,
        "color": 8612593.683130177,
        "value": 18.17665842364471
    },
    {
        "id": 24,
        "x": 1.9550525266491072,
        "y": -1.2617087423016766,
        "z": 0.45069375360614217,
        "color": 1267351.1807711325,
        "value": 51.93002277485876
    },
    {
        "id": 25,
        "x": -0.8104797088955973,
        "y": -0.15404999449917112,
        "z": -1.990812192528903,
        "color": 11748731.078994162,
        "value": 68.25288443513546
    },
    {
        "id": 26,
        "x": -1.1928619475263935,
        "y": -1.5579936479077787,
        "z": -0.5307400488982728,
        "color": 6632869.912878685,
        "value": 95.01329399755087
    },
    {
        "id": 27,
        "x": 1.1505281323062588,
        "y": -0.6695316140553431,
        "z": -0.8144532007020873,
        "color": 10419624.379071308,
        "value": 3.862999228587416
    },
    {
        "id": 28,
        "x": 0.812079021527992,
        "y": -1.4949676500940572,
        "z": 0.6213098548517673,
        "color": 4505565.25630098,
        "value": 82.99141186460459
    },
    {
        "id": 29,
        "x": 1.1142317494761493,
        "y": 0.6183517960146223,
        "z": -1.4377907455815087,
        "color": 6216891.3380881,
        "value": 26.935341666809453
    },
    {
        "id": 30,
        "x": -0.5395272833953784,
        "y": -0.3147819296670269,
        "z": -1.566003714888283,
        "color": 10905813.025405675,
        "value": 27.336692453045664
    },
    {
        "id": 31,
        "x": 0.8720294616409539,
        "y": 0.47310658628028657,
        "z": 1.4311117867434135,
        "color": 4995681.779701817,
        "value": 65.59522376646805
    },
    {
        "id": 32,
        "x": -1.632156855682573,
        "y": -0.37683399109363336,
        "z": -1.285405461089887,
        "color": 12814714.312943649,
        "value": 86.5245008699879
    },
    {
        "id": 33,
        "x": -1.7461046907841267,
        "y": 1.7861834763303608,
        "z": -0.9937474093674674,
        "color": 13798825.933242984,
        "value": 70.12905038069769
    },
    {
        "id": 34,
        "x": -0.37997912123546085,
        "y": -1.1542068085929738,
        "z": 1.8321293085948094,
        "color": 139503.50146350206,
        "value": 70.66272811581057
    },
    {
        "id": 35,
        "x": -1.9753595751933761,
        "y": -0.1229082097694123,
        "z": 0.28864379932155915,
        "color": 6712228.695156552,
        "value": 95.3169226675718
    },
    {
        "id": 36,
        "x": 0.05725053279423342,
        "y": 1.2978227821050896,
        "z": -0.7470126141078297,
        "color": 7688285.467017437,
        "value": 33.35674330666167
    },
    {
        "id": 37,
        "x": -0.628033414521783,
        "y": 0.5370195525785575,
        "z": -1.7815413616224096,
        "color": 13504439.958082825,
        "value": 94.5555710224771
    },
    {
        "id": 38,
        "x": -0.37014421017487953,
        "y": 1.7891060872972595,
        "z": -1.8208326090319544,
        "color": 10517353.918175235,
        "value": 54.05509627558579
    },
    {
        "id": 39,
        "x": 0.15881615912782765,
        "y": -1.3661674692179608,
        "z": 1.2048270397430825,
        "color": 1481211.8107261253,
        "value": 15.443277174667724
    },
    {
        "id": 40,
        "x": 0.6064570392570001,
        "y": 0.7035909525526458,
        "z": -0.5261653260906738,
        "color": 7918018.618055915,
        "value": 17.04645217997649
    },
    {
        "id": 41,
        "x": 0.22004693262911745,
        "y": -1.961195156347626,
        "z": -0.9580665551932452,
        "color": 3252776.6925566006,
        "value": 73.52839481146233
    },
    {
        "id": 42,
        "x": -1.4204775531608562,
        "y": -1.4377967215397365,
        "z": -1.053194413967868,
        "color": 14411858.676479273,
        "value": 56.13362084912738
    },
    {
        "id": 43,
        "x": -0.8180684447359168,
        "y": 1.911167737617192,
        "z": 1.3903171588825196,
        "color": 5538094.5931017,
        "value": 2.8623526523482212
    },
    {
        "id": 44,
        "x": 1.697982191060118,
        "y": -1.2829023485757567,
        "z": -0.6850802499642028,
        "color": 14844154.328218672,
        "value": 34.74215186863081
    },
    {
        "id": 45,
        "x": 1.5469090220337152,
        "y": -1.0591676090346134,
        "z": -1.5756369752435937,
        "color": 5463358.582667403,
        "value": 94.70196636870598
    },
    {
        "id": 46,
        "x": 1.643536225174036,
        "y": -1.845828498497771,
        "z": 0.2707016200373622,
        "color": 9677101.510349946,
        "value": 89.92603890654777
    },
    {
        "id": 47,
        "x": -0.7174309947775614,
        "y": -0.19844351816141037,
        "z": -1.4315624139819798,
        "color": 692112.690260918,
        "value": 70.64663889836207
    },
    {
        "id": 48,
        "x": -0.23318538204850148,
        "y": 0.18773712551065813,
        "z": -1.469834392898687,
        "color": 625313.2471272906,
        "value": 24.756039260785855
    },
    {
        "id": 49,
        "x": -0.343727415580513,
        "y": -1.3719775726645262,
        "z": 0.5711240297873874,
        "color": 11142701.63841437,
        "value": 69.82924622864856
    },
    {
        "id": 50,
        "x": -1.443309673299352,
        "y": 1.6831486129333157,
        "z": -0.8739688395806495,
        "color": 15051537.649827177,
        "value": 63.10643014563726
    },
    {
        "id": 51,
        "x": 1.7728894749987991,
        "y": -0.48374388131833745,
        "z": -0.09385416007191605,
        "color": 460070.22212639265,
        "value": 78.02381186174698
    },
    {
        "id": 52,
        "x": -1.9776841367895877,
        "y": -1.5210233471016705,
        "z": -0.6710852183828915,
        "color": 3635916.75842829,
        "value": 94.6933455816566
    },
    {
        "id": 53,
        "x": -0.5677844905731515,
        "y": -1.0306942019806296,
        "z": 1.3066834025153646,
        "color": 13274573.514561864,
        "value": 32.375005436956215
    },
    {
        "id": 54,
        "x": 1.8000614258416525,
        "y": 1.3655416792036155,
        "z": -0.9704978955964259,
        "color": 329087.13283166126,
        "value": 88.36381020084532
    },
    {
        "id": 55,
        "x": 0.0439979543719744,
        "y": -1.5867288213485402,
        "z": -1.9248754448685954,
        "color": 5866590.206767896,
        "value": 13.521081201824337
    },
    {
        "id": 56,
        "x": -1.8957321686530961,
        "y": 1.065214097711642,
        "z": 0.9562757009687943,
        "color": 1187648.7651659087,
        "value": 95.84656182897294
    },
    {
        "id": 57,
        "x": 1.336887454254895,
        "y": 0.7715289922288,
        "z": 1.6207010808177555,
        "color": 3197916.6068400545,
        "value": 1.089237152326794
    },
    {
        "id": 58,
        "x": 0.29390651137007184,
        "y": 1.9482204553889368,
        "z": -1.9819968058275128,
        "color": 12550043.77511239,
        "value": 84.93171218832286
    },
    {
        "id": 59,
        "x": -1.1824997323375381,
        "y": -0.6882344506542064,
        "z": 0.6565398232094002,
        "color": 14906827.318605648,
        "value": 9.473864044705882
    },
    {
        "id": 60,
        "x": -0.3310229444905941,
        "y": 1.9980585825417103,
        "z": 1.7293183721910852,
        "color": 626936.1569036428,
        "value": 10.563826384661912
    },
    {
        "id": 61,
        "x": -0.9723528262761039,
        "y": 0.7447967331786955,
        "z": 1.431751351453392,
        "color": 1377170.6759946416,
        "value": 0.9404158587886902
    },
    {
        "id": 62,
        "x": 1.2055687201491123,
        "y": 1.4536118847889723,
        "z": -1.548695540420577,
        "color": 6491596.885790457,
        "value": 55.04670082677402
    },
    {
        "id": 63,
        "x": -1.1586495149062226,
        "y": -1.2282116257742977,
        "z": 0.2833502713929148,
        "color": 10824111.40510889,
        "value": 93.274090893801
    },
    {
        "id": 64,
        "x": -0.1398804955597983,
        "y": 0.845026522556334,
        "z": -1.6262956430255788,
        "color": 8147057.246271857,
        "value": 62.9337881995129
    },
    {
        "id": 65,
        "x": -0.9586369396863685,
        "y": -0.2142007016591303,
        "z": 0.29674035697039436,
        "color": 16724261.249435546,
        "value": 1.57685772386702
    },
    {
        "id": 66,
        "x": -0.6534334773453407,
        "y": -1.5193084238216534,
        "z": 0.8448896389385339,
        "color": 8970825.716855794,
        "value": 52.29807771155461
    },
    {
        "id": 67,
        "x": -0.8261855726624647,
        "y": -0.35944526267548316,
        "z": 0.29478010765624507,
        "color": 8474928.459278278,
        "value": 15.386130890669914
    },
    {
        "id": 68,
        "x": -1.4811546671638638,
        "y": 1.2718681529076408,
        "z": -1.372940613980545,
        "color": 14876703.318591164,
        "value": 57.73744997262086
    },
    {
        "id": 69,
        "x": 1.2390373936117305,
        "y": 0.7449793576897816,
        "z": -0.3959269406565,
        "color": 3679215.664706781,
        "value": 40.81791895233435
    },
    {
        "id": 70,
        "x": -1.3247482861990165,
        "y": 0.43095724446040196,
        "z": -1.5909744900509852,
        "color": 10594489.619047327,
        "value": 62.05524380076831
    },
    {
        "id": 71,
        "x": -1.697143472570025,
        "y": -0.16575385471124893,
        "z": -1.3981350650824935,
        "color": 15926894.307732124,
        "value": 93.03630868357067
    },
    {
        "id": 72,
        "x": 1.8446211426372172,
        "y": 0.805172286272831,
        "z": -1.8264964547472302,
        "color": 4222065.69321364,
        "value": 50.79202397936721
    },
    {
        "id": 73,
        "x": 1.264214550173941,
        "y": 1.7255357438766494,
        "z": -1.579487255901983,
        "color": 14267205.502810955,
        "value": 94.01514772167582
    },
    {
        "id": 74,
        "x": 0.32276904157089215,
        "y": -0.3397130700182873,
        "z": 1.4086394995484355,
        "color": 6905797.285483959,
        "value": 66.91708677507394
    },
    {
        "id": 75,
        "x": 1.40284352721473,
        "y": 1.6897709940382213,
        "z": -1.877097990009144,
        "color": 14522229.55968804,
        "value": 83.08445284938061
    },
    {
        "id": 76,
        "x": 1.7649340514464353,
        "y": -1.1337718605732952,
        "z": -0.06629145839976402,
        "color": 9930975.120754339,
        "value": 11.96530571977612
    },
    {
        "id": 77,
        "x": 0.26656645093421316,
        "y": -0.18608856997430046,
        "z": 1.1824532425185197,
        "color": 3127642.9386784825,
        "value": 5.272816560306149
    },
    {
        "id": 78,
        "x": -1.2598919615032989,
        "y": -0.5999152740072264,
        "z": 0.33007616521258454,
        "color": 12608843.349044234,
        "value": 81.65981194288345
    },
    {
        "id": 79,
        "x": -0.7002710061563824,
        "y": -0.033066273199965135,
        "z": 0.03124031275545347,
        "color": 3211871.411090288,
        "value": 90.82986528438967
    },
    {
        "id": 80,
        "x": 1.1318102216748098,
        "y": -0.8639700852986603,
        "z": 1.2452398825653308,
        "color": 8773399.499340529,
        "value": 41.368009315158204
    },
    {
        "id": 81,
        "x": -0.7429539034278823,
        "y": 0.23765073460681796,
        "z": 1.3004446262259974,
        "color": 7301143.966425529,
        "value": 83.04368745406848
    },
    {
        "id": 82,
        "x": -0.8922915512560361,
        "y": 1.8494803387336782,
        "z": -0.05410442465998866,
        "color": 14729291.950813355,
        "value": 95.1274089426516
    },
    {
        "id": 83,
        "x": 1.2218398404395479,
        "y": -0.7988226687001139,
        "z": -1.529293244800809,
        "color": 6183675.729898285,
        "value": 61.74777589800918
    },
    {
        "id": 84,
        "x": 0.3220850617259159,
        "y": 0.6930816896890866,
        "z": -0.9366276324131113,
        "color": 4480625.077026863,
        "value": 3.5255436477623414
    },
    {
        "id": 85,
        "x": 0.043302922725572124,
        "y": -0.6931558393341111,
        "z": -1.8168459630210454,
        "color": 13615118.374869054,
        "value": 77.06632619712549
    },
    {
        "id": 86,
        "x": 1.1994632599979647,
        "y": -0.6393721725711496,
        "z": -1.5254590407845465,
        "color": 4205825.822776792,
        "value": 0.029055698683000397
    },
    {
        "id": 87,
        "x": -0.6586527416472281,
        "y": 0.8874826077881646,
        "z": -0.7093902834672532,
        "color": 1514605.888535903,
        "value": 77.49218362811324
    },
    {
        "id": 88,
        "x": -0.9059664765816433,
        "y": 0.3452916564192532,
        "z": 1.7821756043896761,
        "color": 10772204.860145701,
        "value": 12.126651841889446
    },
    {
        "id": 89,
        "x": 1.6723438805369173,
        "y": 1.7348332908806077,
        "z": 1.2312463723106708,
        "color": 7695265.775306991,
        "value": 32.61749836657246
    },
    {
        "id": 90,
        "x": 0.6586153745685235,
        "y": 1.451151440801469,
        "z": -1.1842640586231536,
        "color": 9585312.386937352,
        "value": 51.955928069606585
    },
    {
        "id": 91,
        "x": -1.1359061597746223,
        "y": 0.5698666986167211,
        "z": 0.2652459215342402,
        "color": 3157763.848354846,
        "value": 17.038554478675028
    },
    {
        "id": 92,
        "x": -0.44581247721622974,
        "y": 0.5509519198331634,
        "z": -0.7498399909238116,
        "color": 15826197.074178725,
        "value": 37.46387951969889
    },
    {
        "id": 93,
        "x": 1.148330882041205,
        "y": 1.3487764611200754,
        "z": 0.6439031178133661,
        "color": 11899224.876399646,
        "value": 68.73627544044032
    },
    {
        "id": 94,
        "x": 0.16706207551353547,
        "y": -0.6417424908466351,
        "z": 1.9797831231862721,
        "color": 5183853.497668097,
        "value": 39.201722571815544
    },
    {
        "id": 95,
        "x": -0.10688289549894225,
        "y": -0.5418370959710854,
        "z": -0.015586205795025343,
        "color": 4986094.56434255,
        "value": 99.99092579498125
    },
    {
        "id": 96,
        "x": -0.84522439160044,
        "y": 1.354878128825126,
        "z": 0.032567078745119105,
        "color": 9865456.928913627,
        "value": 56.799358406971734
    },
    {
        "id": 97,
        "x": -0.9772132512470129,
        "y": 1.7581325184439676,
        "z": -0.7117953831202102,
        "color": 14544028.126028487,
        "value": 84.10689052204847
    },
    {
        "id": 98,
        "x": 0.039898172380225194,
        "y": -1.3769076126814204,
        "z": -0.6170754471347468,
        "color": 12901286.697666176,
        "value": 4.883331845198091
    },
    {
        "id": 99,
        "x": 0.9453184397101655,
        "y": 0.880754963250125,
        "z": -0.8082030851494961,
        "color": 15456277.326788604,
        "value": 27.826319664452082
    }
]
////console.log(SCATTER_DATA);
// Implementation of mergeAttributes function needed by mergeGeometries
function mergeAttributes(attributes) {
    let TypedArray;
    let itemSize;
    let normalized;
    let gpuType = -1;
    let arrayLength = 0;
    for (let i = 0; i < attributes.length; ++i) {
        const attribute = attributes[i];
        if (TypedArray === undefined) TypedArray = attribute.array.constructor;
        if (TypedArray !== attribute.array.constructor) {
            console.error('THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes.');
            return null;
        }
        if (itemSize === undefined) itemSize = attribute.itemSize;
        if (itemSize !== attribute.itemSize) {
            console.error('THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes.');
            return null;
        }
        if (normalized === undefined) normalized = attribute.normalized;
        if (normalized !== attribute.normalized) {
            console.error('THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes.');
            return null;
        }
        if (gpuType === -1) gpuType = attribute.gpuType;
        if (gpuType !== attribute.gpuType) {
            console.error('THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes.');
            return null;
        }
        arrayLength += attribute.count * itemSize;
    }
    const array = new TypedArray(arrayLength);
    const result = new THREE.BufferAttribute(array, itemSize, normalized);
    let offset = 0;
    for (let i = 0; i < attributes.length; ++i) {
        const attribute = attributes[i];
        if (attribute.isInterleavedBufferAttribute) {
            const tupleOffset = offset / itemSize;
            for (let j = 0, l = attribute.count; j < l; j++) {
                for (let c = 0; c < itemSize; c++) {
                    const value = attribute.getComponent(j, c);
                    result.setComponent(j + tupleOffset, c, value);
                }
            }
        } else {
            array.set(attribute.array, offset);
        }
        offset += attribute.count * itemSize;
    }
    if (gpuType !== undefined) {
        result.gpuType = gpuType;
    }
    return result;
}
// Implementation of mergeGeometries function from BufferGeometryUtils
function mergeGeometries(geometries, useGroups = false) {
    const isIndexed = geometries[0].index !== null;
    const attributesUsed = new Set(Object.keys(geometries[0].attributes));
    const morphAttributesUsed = new Set(Object.keys(geometries[0].morphAttributes));
    const attributes = {};
    const morphAttributes = {};
    const morphTargetsRelative = geometries[0].morphTargetsRelative;
    const mergedGeometry = new THREE.BufferGeometry();
    let offset = 0;
    for (let i = 0; i < geometries.length; ++i) {
        const geometry = geometries[i];
        let attributesCount = 0;
        // ensure that all geometries are indexed, or none
        if (isIndexed !== (geometry.index !== null)) {
            console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them.');
            return null;
        }
        // gather attributes, exit early if they're different
        for (const name in geometry.attributes) {
            if (!attributesUsed.has(name)) {
                console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. All geometries must have compatible attributes; make sure "' + name + '" attribute exists among all geometries, or in none of them.');
                return null;
            }
            if (attributes[name] === undefined) attributes[name] = [];
            attributes[name].push(geometry.attributes[name]);
            attributesCount++;
        }
        // ensure geometries have the same number of attributes
        if (attributesCount !== attributesUsed.size) {
            console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. Make sure all geometries have the same number of attributes.');
            return null;
        }
        // gather morph attributes, exit early if they're different
        if (morphTargetsRelative !== geometry.morphTargetsRelative) {
            console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. .morphTargetsRelative must be consistent throughout all geometries.');
            return null;
        }
        for (const name in geometry.morphAttributes) {
            if (!morphAttributesUsed.has(name)) {
                console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '.  .morphAttributes must be consistent throughout all geometries.');
                return null;
            }
            if (morphAttributes[name] === undefined) morphAttributes[name] = [];
            morphAttributes[name].push(geometry.morphAttributes[name]);
        }
        if (useGroups) {
            let count;
            if (isIndexed) {
                count = geometry.index.count;
            } else if (geometry.attributes.position !== undefined) {
                count = geometry.attributes.position.count;
            } else {
                console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index ' + i + '. The geometry must have either an index or a position attribute');
                return null;
            }
            mergedGeometry.addGroup(offset, count, i);
            offset += count;
        }
    }
    // merge indices
    if (isIndexed) {
        let indexOffset = 0;
        const mergedIndex = [];
        for (let i = 0; i < geometries.length; ++i) {
            const index = geometries[i].index;
            for (let j = 0; j < index.count; ++j) {
                mergedIndex.push(index.getX(j) + indexOffset);
            }
            indexOffset += geometries[i].attributes.position.count;
        }
        mergedGeometry.setIndex(mergedIndex);
    }
    // merge attributes
    for (const name in attributes) {
        const mergedAttribute = mergeAttributes(attributes[name]);
        if (!mergedAttribute) {
            console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the ' + name + ' attribute.');
            return null;
        }
        mergedGeometry.setAttribute(name, mergedAttribute);
    }
    // merge morph attributes
    for (const name in morphAttributes) {
        const numMorphTargets = morphAttributes[name][0].length;
        if (numMorphTargets === 0) break;
        mergedGeometry.morphAttributes = mergedGeometry.morphAttributes || {};
        mergedGeometry.morphAttributes[name] = [];
        for (let i = 0; i < numMorphTargets; ++i) {
            const morphAttributesToMerge = [];
            for (let j = 0; j < morphAttributes[name].length; ++j) {
                morphAttributesToMerge.push(morphAttributes[name][j][i]);
            }
            const mergedMorphAttribute = mergeAttributes(morphAttributesToMerge);
            if (!mergedMorphAttribute) {
                console.error('THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the ' + name + ' morphAttribute.');
                return null;
            }
            mergedGeometry.morphAttributes[name].push(mergedMorphAttribute);
        }
    }
    return mergedGeometry;
}
export function createScatterGeometry() {
    const baseGeometry = new THREE.SphereGeometry(0.08, 8, 8);
    const geometries = SCATTER_DATA.map(point => {
        const g = baseGeometry.clone();
        g.translate(point.x, point.y, point.z);
        return g;
    });
    // Use our extracted mergeGeometries function instead of the imported one
    const geometry = mergeGeometries(geometries);
    geometry.scale(0.75, 0.75, 0.75);
    return geometry;
}