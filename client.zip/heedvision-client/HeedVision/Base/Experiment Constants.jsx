/**
 * Experiment configuration constants.
 * Modify these constants to change the behavior of the experiment.
 * 
 * TYPE: Unique identifier for the experiment. Used in logging and data storage.
 * DEBUG: Enable or disable debug mode for additional console logging.
 * SHOW_VOXELS: Enable or disable voxel rendering in the experiment.
 * GEOMETRY_NAME: Default geometry for voxel placement. Supported values: "Scatter", "Terrain", "Sphere".
 */
export const EXPERIMENT_CONFIG = {
    // Can take any value, but should be unique for each experiment
    // Used to identify the experiment in logs and data storage
    // "demo-no-voxels" | "terrain-voxels" | "terrain-no-voxels" | "scatter-voxels" | "scatter-no-voxels"
    TYPE: "demo-voxels", 
    // Enable or disable debug mode to log additional information to console
    DEBUG: false,
    // Enable or disable voxel rendering in the experiment (enables or disables voxel-related components)
    SHOW_VOXELS: true,
    // Default geometry to use for placing the voxels over.
    // Currently supported: "Scatter", "Terrain", "Sphere"
    GEOMETRY_NAME: "Sphere"
}