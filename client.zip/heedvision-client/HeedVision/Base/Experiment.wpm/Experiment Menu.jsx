/**
 * Experiment Menu
 *
 * This file sets up the Experiment menu in the VR environment.
 * It includes buttons to start and end the experiment, which trigger
 * custom events that other components can listen to.
 *
 * The menu is accessible from both the main menu and the controller menu.
 */
import React from 'react';
import {
    addSubMenu,
    addItemToSubMenu,
    MenuTitle,
    MenuButton
} from '#Menu .default';
import {
    addItem,
    ControllerMenuButton
} from '#ControllerMenu .default';
import { getCurrentEnclosure, getLocalUser, clearAllLogsForLocalUser } from '#VoxelStore .helpers';
let alreadyStarted = false;
let alreadyEnded = false;
const handleStartExperiment = async () => {
    const user = await getLocalUser();
    const enclosure = await getCurrentEnclosure();
    if (alreadyStarted) {
        console.warn('Experiment already started');
        return;
    }
    // Clear any previous logs from VoxelStore for User
    await clearAllLogsForLocalUser();
    // Trigger event on start of experiment so that other components can listen to it
    // This is useful for components that need to reset their state when the experiment starts
    const experimentStartEvent = new CustomEvent('experiment-start', {
      detail: { 
        timestamp: Date.now(),
        user: user.name,
        enclosure: enclosure.name
      }
    });
    document.dispatchEvent(experimentStartEvent);
    // Start the experiment and flag it
    alreadyStarted = true;
    // Do not reset the state of the experiment once started. 
    // Only full reload of the application will reset the state.
}
const handleEndExperiment = async () => {
    const user = await getLocalUser();
    const enclosure = await getCurrentEnclosure();
    if (alreadyEnded) {
        console.warn('Experiment already ended');
        return;
    }
    // Trigger event on end of experiment so that other components can listen to it
    // This is useful for components that need to reset their state when the experiment ends
    const experimentEndEvent = new CustomEvent('experiment-end', {
      detail: { 
        timestamp: Date.now(),
        user: user.name,
        enclosure: enclosure.name
      }
    });
    document.dispatchEvent(experimentEndEvent);
    // End the experiment and flag it
    alreadyEnded = true;
    // Do not reset the state of the experiment once ended. 
    // Only full reload of the application will reset the state.
}
addSubMenu('experiment', 100, false);
addItemToSubMenu('experiment', 'title', <MenuTitle title="Experiment" />, 0);
addItemToSubMenu('experiment', 'start', <MenuButton onClick={handleStartExperiment}>Start Experiment</MenuButton>, 500);
addItemToSubMenu('experiment', 'end', <MenuButton onClick={handleEndExperiment}>End Experiment</MenuButton>, 500);
addItem('start', <ControllerMenuButton position={[0.2, 0.06, 0]} name={'Start Experiment'} callback={handleStartExperiment} />);
addItem('end', <ControllerMenuButton position={[0.2, 0, 0]} name={'End Experiment'} theme="deleteButton" callback={handleEndExperiment} />);