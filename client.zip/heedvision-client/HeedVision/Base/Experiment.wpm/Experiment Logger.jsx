/**
 * logService.js
 * =============
 * Simplified logging functions for HeedVision.
 * Provides atomic functions for adding and committing logs.
 */
// Constants for server endpoints
const LOCAL = false;
// When deploying your own server, replace the HOSTED_SERVER_API_URL below with your server's URL endpoint.
// I recommend using a service like Railway, Render, or Heroku to host your own instance of the HeedVision server.
const HOSTED_SERVER_API_URL = 'heedvision.server.com'
const SERVER_URL = LOCAL ? 'localhost:3000' : HOSTED_SERVER_API_URL; 
const WS_ENDPOINT = `ws${LOCAL ? '':'s'}://${SERVER_URL}`;
const HTTP_ENDPOINT = `http${LOCAL ? '':'s'}://${SERVER_URL}/api/v1`;
// Default configuration
const DEFAULT_CONFIG = {
  maxBatchSize: 100,         // Maximum number of logs to send in a single batch
  useWebSocketOnly: false,   // If true, will only use WebSocket (no HTTP fallback)
};
// Module state
let pendingLogs = [];
let wsConnection = null;
let wsConnected = false;
let pendingRequests = {};
let config = { ...DEFAULT_CONFIG };
/**
 * Initialize WebSocket connection if needed
 * @returns {WebSocket} WebSocket connection
 */
function getWebSocketConnection() {
  // If connected, return existing connection
  if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
    return wsConnection;
  }
  // Clean up existing connection if any
  if (wsConnection) {
    wsConnection.close();
    wsConnection = null;
    wsConnected = false;
  }
  // Create new connection
  const ws = new WebSocket(WS_ENDPOINT);
  ws.onopen = () => {
    //console.log(`[logService] WebSocket connected`);
    wsConnected = true;
  };
  ws.onclose = () => {
    //console.log(`[logService] WebSocket disconnected`);
    wsConnected = false;
    wsConnection = null;
    // Failed pending requests
    Object.keys(pendingRequests).forEach(requestId => {
      const { reject } = pendingRequests[requestId];
      reject(new Error('WebSocket connection closed'));
      delete pendingRequests[requestId];
    });
  };
  ws.onerror = (error) => {
    console.error(`[logService] WebSocket error:`, error);
    wsConnected = false;
  };
  ws.onmessage = (event) => {
    try {
      const response = JSON.parse(event.data);
      // Handle response to a pending request
      if (response.requestId && pendingRequests[response.requestId]) {
        const { resolve } = pendingRequests[response.requestId];
        resolve(response);
        delete pendingRequests[response.requestId];
      }
    } catch (error) {
      console.error(`[logService] Error handling WebSocket message:`, error);
    }
  };
  wsConnection = ws;
  return ws;
}
/**
 * Send logs via WebSocket
 * @param {Array} logs - Array of log entries to send
 * @returns {Promise<Object>} - WebSocket response
 */
function sendLogsWs(logs) {
  return new Promise((resolve, reject) => {
    try {
      // Generate a unique request ID
      const requestId = `send-logs-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      // Store the promise callbacks for later resolution
      pendingRequests[requestId] = { resolve, reject };
      // Make sure we have a connection
      const ws = getWebSocketConnection();
      // Wait for connection to open if needed
      if (ws.readyState === WebSocket.CONNECTING) {
        ws.addEventListener('open', () => {
          ws.send(JSON.stringify({
            operation: 'store-logs',
            logs: logs,
            requestId: requestId
          }));
        });
      } else if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          operation: 'store-logs',
          logs: logs,
          requestId: requestId
        }));
      } else {
        throw new Error('WebSocket is not open');
      }
      // Set up a timeout for the request
      setTimeout(() => {
        if (pendingRequests[requestId]) {
          pendingRequests[requestId].reject(new Error('WebSocket request timed out'));
          delete pendingRequests[requestId];
        }
      }, 10000); // 10 second timeout
    } catch (error) {
      reject(error);
    }
  });
}
/**
 * Send logs via HTTP
 * @param {Array} logs - Array of log entries to send
 * @returns {Promise<Object>} - HTTP response
 */
async function sendLogsHttp(logs) {
  try {
    //console.log(`[logService] HTTP request to store ${logs.length} logs`);
    const response = await fetch(`${HTTP_ENDPOINT}/logs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(logs)
    });
    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('[logService] HTTP error sending logs:', error);
    throw error;
  }
}
/**
 * Add a log entry to the pending queue
 * @param {string} action - The action type (e.g., 'INITIALIZE_VOXELS')
 * @param {Object} contextData - Additional data to include in context
 * @param {string} user - The user who performed the action
 * @param {string} enclosureId - The enclosure related to the action (will be added to context)
 * @returns {Object} The created log entry
 */
export function addLog(action, contextData, user, enclosureId) {
  if (!action || !user) {
    console.error("[logService] Invalid log data:", { action, user });
    return null;
  }
  // Create context object with enclosureId
  const context = {
    ...contextData,
    enclosureId
  };
  // Create log entry with current timestamp (matching schema)
  const logEntry = {
    action,
    user,
    context,
    timestamp: Date.now()
  };
  // Add to pending logs
  pendingLogs.push(logEntry);
  return logEntry;
}
/**
 * Send pending logs to the server
 * @returns {Promise<Object>} Result of the commit operation
 */
export async function commitLogs() {
  if (pendingLogs.length === 0) {
    return { success: true, count: 0 };
  }
  //console.log(`[logService] Committing ${pendingLogs.length} logs`);
  try {
    // Get logs to commit and clear pending
    const logsToCommit = [...pendingLogs];
    pendingLogs = [];
    // Process logs in batches with a maximum batch size
    const results = [];
    for (let i = 0; i < logsToCommit.length; i += config.maxBatchSize) {
      const batch = logsToCommit.slice(i, i + config.maxBatchSize);
      if (batch.length > 0) {
        try {
          // Try WebSocket first
          if (wsConnected || !config.useWebSocketOnly) {
            try {
              const result = await sendLogsWs(batch);
              results.push(result);
              continue; // Skip HTTP if WebSocket succeeds
            } catch (wsError) {
              //console.log('[logService] WebSocket send failed, falling back to HTTP');
            }
          }
          // Fall back to HTTP if WebSocket fails and fallback is allowed
          if (!config.useWebSocketOnly) {
            const result = await sendLogsHttp(batch);
            results.push(result);
          }
        } catch (error) {
          console.error('[logService] Failed to send batch:', error);
          // Put logs back in the queue
          pendingLogs.push(...batch);
          results.push({ success: false, error: error.message });
        }
      }
    }
    const successfulBatches = results.filter(r => r.success).length;
    //console.log(`[logService] Committed ${successfulBatches}/${results.length} log batches`);
    return {
      success: true,
      count: logsToCommit.length - pendingLogs.length, // Subtract logs that went back to pending
      batchesSucceeded: successfulBatches,
      batchesTotal: results.length
    };
  } catch (error) {
    console.error("[logService] Error during commit:", error);
    return {
      success: false,
      error: error.message
    };
  }
}
/**
 * Create a log and immediately commit it
 * @param {string} action - The action type
 * @param {Object} contextData - Additional data to include in context
 * @param {string} user - The user who performed the action
 * @param {string} enclosureId - The enclosure related to the action
 * @returns {Promise<Object>} Result of the commit operation
 */
export async function logAndCommit(action, contextData, user, enclosureId) {
  addLog(action, contextData, user, enclosureId);
  return commitLogs();
}
/**
 * Update the configuration
 * @param {Object} newConfig - New configuration options
 * @returns {Object} - Updated configuration
 */
export function configure(newConfig = {}) {
  config = {
    ...config,
    ...newConfig
  };
  //console.log("[logService] Configuration updated");
  return config;
}
/**
 * Clear all pending logs without sending them
 * @returns {number} Number of logs cleared
 */
export function clearPendingLogs() {
  const count = pendingLogs.length;
  pendingLogs = [];
  return count;
}
/**
 * Get the number of pending logs
 * @returns {number} Number of pending logs
 */
export function getPendingLogCount() {
  return pendingLogs.length;
}
/**
 * React hook for logging actions within components
 * @param {string} user - The current user
 * @param {string} enclosureId - The current enclosure
 * @returns {Object} Logging functions
 */
import { useCallback } from 'react';
export function useLogging(user, enclosureId) {
  const log = useCallback(
    (action, contextData = {}) => addLog(action, contextData, user, enclosureId),
    [user, enclosureId]
  );
  const logAndCommitNow = useCallback(
    async (action, contextData = {}) => logAndCommit(action, contextData, user, enclosureId),
    [user, enclosureId]
  );
  return {
    log,
    logAndCommitNow,
    commitLogs,
    pendingCount: getPendingLogCount
  };
}