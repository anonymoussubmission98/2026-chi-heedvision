import { logAndCommit } from "#Experiment .logger";
import * as THREE from "three";
const DEBUG = true;
/**
 * This function logs debug messages to the console if DEBUG is enabled.
 * @param  {...any} args The arguments to log.
 * @returns {void}
 */
const info = (...args) => {
  if (DEBUG) {
    //console.log("[VoxelStore]",...args);
  }
}
function ifTarget(voxelUuid, targetIds) {
  const instanceId = extractVoxelIndex(voxelUuid);
  if (targetIds && targetIds.length > 0) {
    for (const targetId of targetIds) {
      if (targetId === instanceId) {
        return true;
      }
    }
  }
  return false;
}
async function clearAllLogsForLocalUser() {
  // Clear all logs for the local user
  const user = await getLocalUser();
  if (user) {
    const userName = user?.name.toLowerCase();
    VarvEngine.lookupInstances("VoxelStore").then((instances) => {
      instances.forEach((instance) => {
        const voxelConcept = VarvEngine.getConceptFromUUID(instance);
        if (voxelConcept) {
          const instanceUserId = voxelConcept.getPropertyValue(instance, "user");
          if (instanceUserId === userName) {
            voxelConcept.delete(instance);
          }
        }
      });
    });
  }
}
/**
 * This function looks up the instances of the "Enclosure" concept
 * and retrieves the first instance's ID and name.
 * If no instances are found, it returns null.
 * @returns {Promise<{id: string, name: string}>}
 */
async function getCurrentEnclosure() {
  const enclosureInstances = await VarvEngine.lookupInstances("Enclosure");
  if (enclosureInstances.length) {
    const currentEnclosureID = enclosureInstances[0];
    const currentEnclosureConcept = await VarvEngine.getConceptFromUUID(
      currentEnclosureID
    );
    const currentEnclosureName =
      (await currentEnclosureConcept.getPropertyValue(
        currentEnclosureID,
        "name"
      )) || null;
    return {
      id: currentEnclosureID,
      name: currentEnclosureName,
    };
  }
  return null;
}
/**
 * This function retrieves the local user ID and name from the UserManager concept.
 * It returns an object containing the user's ID and name.
 * If the user is not found, it returns null.
 * @returns {Promise<{id: string, name: string}>}
 */
async function getLocalUser() {
  const userManager = await VarvEngine.lookupInstances("UserManager");
  if (userManager.length) {
    const userManagerID = userManager[0];
    const userManagerConcept = await VarvEngine.getConceptFromUUID(
      userManagerID
    );
    const localUserID =
      userManagerConcept.getPropertyValue(userManagerID, "localUser") || null;
    const localUserConcept = await VarvEngine.getConceptFromUUID(localUserID);
    const localUsername =
      localUserConcept.getPropertyValue(localUserID, "name") || "Anonymous";
    return {
      id: localUserID,
      name: localUsername,
    };
  }
  return null;
}
async function getAlternateID(voxelUuid) {
  const voxelUsername = voxelUuid.split("#")[0];
  const users = await VarvEngine.lookupInstances("User");
  for (const user of users) {
    const userConcept = await VarvEngine.getConceptFromUUID(user);
    const userName = userConcept.getPropertyValue(user, "name");
    if (userName.toLowerCase() !== voxelUsername.toLowerCase()) {
      return voxelUuid.replace(voxelUsername, userName.toLowerCase());
    }
  }
}
async function isLocalUser(userName) {
  const user = await getLocalUser();
  if (user) {
    return user.name.toLowerCase() === userName.toLowerCase();
  }
  return false;
}
async function getColorForUuid(voxelUuid) {
  const voxelUsername = voxelUuid.split("#")[0];
  const userIsLocal = await isLocalUser(voxelUsername)
  const alternateID = await getAlternateID(voxelUuid);
  const alternateConcept = await VarvEngine.getConceptFromUUID(alternateID);
  if (userIsLocal) {
    if (alternateConcept) {
      return MUTUAL_USER_COLOR;
    } else {
      return LOCAL_USER_COLOR;
    }
  } else {
    if (alternateConcept) {
      return MUTUAL_USER_COLOR;
    } else {
      return OTHER_USER_COLOR;
    }
  }
}
/**
 * This function generates a VoxelStore ID based on the user's ID and name,
 * the enclosure's ID and name, and the instance ID.
 * It returns the VoxelStore ID in the format:
 * `userID#enclosureID#instanceID` or `username#enclosurename#instanceID`
 * based on the byID parameter.
 * @param {string} instanceId - The instance ID to include in the VoxelStore ID.
 * @param {boolean} [byID=false] - Whether to use IDs instead of names. False by default.
 * @returns {Promise<string>} The generated VoxelStore ID.
 * @throws Will throw an error if instanceId is not provided.
 */
async function getVoxelStoreID(instanceId, byID = false) {
  const user = await getLocalUser();
  const enclosure = await getCurrentEnclosure();
  if (!instanceId && instanceId !== 0) {
    throw new Error("Instance ID is required to generate the VoxelStore ID.");
  }
  if (user && enclosure) {
    if (byID) {
      return `${user.id}#${enclosure.id}#${instanceId}`;
    }
    return `${user.name.toLowerCase()}#${enclosure.name.toLowerCase()}#${instanceId}`;
  }
  console.error("User or enclosure not found. Cannot generate VoxelStore ID.");
  return null;
}
/**
 * Get or create a Voxel concept instance in VarvEngine.
 * This function checks if a Voxel concept with the given UUID exists.
 * If it does, it returns the existing concept.
 * If it doesn't, it creates a new Voxel concept with the specified properties.
 * @param {string} voxelUuid - The UUID of the Voxel concept.
 * @returns {Promise<Object>} The Voxel concept instance.
*/
async function getOrCreateVoxel(voxelUuid) {
  try {
    let voxelStoreConcept = await VarvEngine.getConceptFromUUID(voxelUuid);
    if (!voxelStoreConcept) {
      info(`Cannot find existing concept in VoxelStore for ${voxelUuid}. Creating...`);
      await VarvEngine.getConceptFromType("VoxelStore").create(voxelUuid, {
        user: voxelUuid.split("#")[0],
        attention: 0,
        lastSeen: Date.now(),
        distance: 0,
        isTarget: false
      });
      voxelStoreConcept = await VarvEngine.getConceptFromUUID(voxelUuid);
      info(`Voxel concept created with UUID: ${voxelUuid}`);
      logAndCommit("create-voxel", {
        voxelUuid,
        attention: 0,
        distance: 0,
        lastSeen: Date.now(),
        isTarget: false
      }, voxelUuid.split("#")[0], voxelUuid.split("#")[1]);
    }
    return voxelStoreConcept;
  } catch (error) {
    console.error(`Error creating or retrieving concept from VoxelStore: ${error}`);
    return null;
  }
}
/**
 * Update the attention value for a voxel in Varv
 * @param {string} voxelUuid The UUID of the voxel to update
 * @param {Object} voxelStoreConcept The corresponding VoxelStore concept instance in Varv
 * @returns {Promise<number>} The new attention value or 0 if an error occurs
 */
async function updateVoxelAttention(voxelUuid, voxelStoreConcept, distance, targetIds) {
  if (!voxelStoreConcept) return 0;
  try {
    const currentAttention = voxelStoreConcept.getPropertyValue(voxelUuid, "attention") || 0;
    const currentIsTarget = voxelStoreConcept.getPropertyValue(voxelUuid, "isTarget") || false;
    const increment = 0.2;
    const newAttention = Math.min(1.0, currentAttention + increment);
    await voxelStoreConcept.setPropertyValue(
      voxelUuid,
      "attention",
      newAttention
    );
    await voxelStoreConcept.setPropertyValue(
      voxelUuid,
      "distance",
      distance
    );
    await voxelStoreConcept.setPropertyValue(
      voxelUuid,
      "lastSeen",
      Date.now()
    );
    await voxelStoreConcept.setPropertyValue(
      voxelUuid,
      "isTarget",
      ifTarget(voxelUuid, targetIds)
    );
    info(`Voxel attention updated for ${voxelUuid}: ${newAttention}`);
    logAndCommit("update-voxel-attention", {
      voxelUuid,
      attention: newAttention,
      distance,
      lastSeen: Date.now()
    }, voxelUuid.split("#")[0], voxelUuid.split("#")[1]);
    return newAttention;
  } catch (error) {
    console.error(`Error updating voxel attention for ${voxelUuid}: ${error}`);
    return 0;
  }
}
/**
 * Extract the instance index from a voxel UUID.
 * The voxel UUID is expected to be in the format:
 * `userID#enclosureID#instanceID` or `username#enclosurename#instanceID`.
 * The instance ID is the last part of the UUID, separated by `#`.
 * This function returns the index as a number.
 * @param {string} voxelUuid The voxel ID to extract the index from.
 * @returns {number} The extracted index or -1 if invalid
 */
function extractVoxelIndex(voxelUuid) {
  const parts = voxelUuid.split("#");
  if (parts.length < 3) {
    console.error(`Invalid voxel UUID format: ${voxelUuid}`);
    return -1;
  }
  const index = parseInt(parts[parts.length - 1], 10);
  return isNaN(index) ? -1 : index;
}
/**
 * This function loads the attention values from VoxelStore in Varv and extracts 
 * their attention values, updating the corresponding opacities in the VoxelLayer.
 * @param {React.Ref} voxelInstancedMeshRef Reference to the voxel instanced mesh
 * @param {Array} voxelPositions Array of voxel positions
 * @returns {Promise<void>}
 */
/* // TODO: Update this function to use voxelInstancedMeshRef to update opacities
async function loadVoxelAttentionValues(voxelPositions) {
  try {
    info("Loading voxel attention values from Varv...");
    const voxelStoreInstances = await VarvEngine.lookupInstances("VoxelStore");
    if (!voxelStoreInstances || voxelStoreInstances.length === 0) {
      console.warn("No VoxelStore instances found in Varv");
      return;
    }
    info(`Found ${voxelStoreInstances.length} VoxelStore instances in Varv`);
    // Process each instance
    let updatedCount = 0;
    for (const voxelUuid of voxelStoreInstances) {
      const voxelConcept = await VarvEngine.getConceptFromUUID(voxelUuid);
      if (!voxelConcept) continue;
      const attention = voxelConcept.getPropertyValue(voxelUuid, "attention") || 0;
      const instanceId = extractVoxelIndex(voxelUuid);
      if (instanceId >= 0 && instanceId < voxelPositions.length) {
        info(`Will update opacity for instanceId here: ${instanceId}, attention: ${attention}`);
        updatedCount++;
      }
    }
    info(`Updated opacities for ${updatedCount} voxels from Varv state`);
  }
  catch (error) {
    console.error("Error loading attention values from Varv:", error);
  }
} */
export const LOCAL_USER_COLOR = "skyblue";
export const OTHER_USER_COLOR = "gold";
export const MUTUAL_USER_COLOR = "lightpink";
/**
 * Converts HSL color values to RGB color values.
 * @param {Object} hsl - The HSL color object.
 * @param {number} hsl.h - The hue value (0-1).
 * @param {number} hsl.s - The saturation value (0-1).
 * @param {number} hsl.l - The lightness value (0-1).
 * @returns {Object} An object with r, g, b properties (all 0-1).
 */
function hslToRgb(hsl) {
  // Destructure hsl values
  let { h, s, l } = hsl;
  // Ensure h is between 0 and 1
  h = ((h % 1) + 1) % 1;
  // Clamp s and l between 0 and 1
  s = Math.max(0, Math.min(1, s));
  l = Math.max(0, Math.min(1, l));
  // If saturation is 0, it's a shade of gray
  if (s === 0) {
    return { r: l, g: l, b: l };
  }
  // Helper function to convert hue to RGB component
  const hueToRgb = (p, q, t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1/6) return p + (q - p) * 6 * t;
    if (t < 1/2) return q;
    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
    return p;
  };
  // Calculate q and p values based on lightness and saturation
  const q = l < 0.5 ? l * (1 + s) : l + s - (l * s);
  const p = 2 * l - q;
  // Calculate RGB values using hue
  const r = hueToRgb(p, q, h + 1/3);
  const g = hueToRgb(p, q, h);
  const b = hueToRgb(p, q, h - 1/3);
  return { r, g, b };
}
async function getVoxelEmissivity(voxelUuid, distance) {
  if (!isLocalUser(voxelUuid.split("#")[0])) return 0;
  const voxelConcept = await VarvEngine.getConceptFromUUID(voxelUuid);
  if (!voxelConcept) {
    console.warn(`Voxel concept not found for UUID: ${voxelUuid}`);
    return 0;
  }
  const isTarget = voxelConcept.getPropertyValue(voxelUuid, "isTarget");
  if (!isTarget) {
    return 0;
  }
  //console.log("Computing emissivity for voxelUuid", voxelUuid, "distance", distance); 
  return Math.max(0, Math.min(1.2, Math.abs(1.2 - distance)));
}
function getUpdatedColorWithEmissivity(color, emissivity) {
  const hsl = {};
  color.getHSL(hsl);
  // Adjust the lightness based on emissivity
  // This increases brightness to create a glow effect
  const newLightness = Math.min(hsl.l + emissivity * 0.5, 1.0);
  const updatedColor = {
    h: hsl.h,
    s: hsl.s,
    l: newLightness,
  }
  const rgb = hslToRgb(updatedColor);
  return rgb;
}
function updateVoxelOpacity(voxelInstancedMeshRef, instanceId, opacity, userColor, emissivity, showVoxels, voxelUuid, name) {
  const color = new THREE.Color(userColor);
  if (!voxelInstancedMeshRef.current || 
      !voxelInstancedMeshRef.current.geometry) {
    console.warn("VoxelLayer not ready or geometry not available");
    return;
  }
  const colorAttribute = voxelInstancedMeshRef.current.geometry.getAttribute('instanceColor');
  if (!colorAttribute) {
    console.warn("instanceColor attribute not found in VoxelLayer");
    return;
  }
  const opacityAttribute = voxelInstancedMeshRef.current.geometry.getAttribute('instanceOpacity');
  if (!opacityAttribute) {
    console.warn("instanceOpacity attribute not found in VoxelLayer");
    return;
  }
  const emissivityAttribute = voxelInstancedMeshRef.current.geometry.getAttribute('instanceEmissive');
  if (!emissivityAttribute) {
    console.warn("instanceEmissive attribute not found in VoxelLayer");
    return;
  }
  if (instanceId < 0 || instanceId >= opacityAttribute.array.length) {
    console.warn(`Instance ID ${instanceId} out of bounds (0-${opacityAttribute.array.length-1})`);
    return;
  }
  if (instanceId < 0 || instanceId >= emissivityAttribute.array.length) {
    console.warn(`Instance ID ${instanceId} out of bounds (0-${emissivityAttribute.array.length-1})`);
    return;
  }
  const updatedRGB = getUpdatedColorWithEmissivity(color, emissivity);
  // Update color and opacity for the instance
  colorAttribute.array[instanceId * 3] = updatedRGB.r;
  colorAttribute.array[instanceId * 3 + 1] = updatedRGB.g;
  colorAttribute.array[instanceId * 3 + 2] = updatedRGB.b;
  opacityAttribute.array[instanceId] = showVoxels ? opacity : (emissivity > 0 ? (emissivity < 0.6 ? 0 : (name.toLowerCase() == voxelUuid.split("#")[0].toLowerCase() ? opacity : 0)) : 0);
      //console.log("Setting opacity for instanceId", instanceId, "to", opacity,"emissivity", emissivity, "updated opacity", opacityAttribute.array[instanceId]);
  /* if (emissivity > 0) {
    // Set emissivity value for the instance
    emissivityAttribute.array[instanceId] = emissivity;
    console.log("Setting emissivity for instanceId", instanceId, "to", emissivity, emissivityAttribute.array[instanceId]);
  } */
  /* let finalOpacity;
  // Check if voxels should be displayed
  if (showVoxels) {
    // If yes, use the provided opacity value
    finalOpacity = opacity;
  } else {
    // If voxels should not be displayed, evaluate emissivity
    if (emissivity > 0) {
      // If emissivity is greater than 0, further check its value to see if its greater than a threshold (0.94)
      if (emissivity > 0.94) {
        // If emissivity (1-distance) is less than this threshold, set opacity to 0
        finalOpacity = 0;
      } else {
        // If emissivity is 0.94 or higher, compare names
        const voxelName = voxelUuid.split("#")[0].toLowerCase(); // Extract and lowercase the voxel name
        const currentName = name.toLowerCase(); // Lowercase the current name
        // If names match, use the provided opacity; otherwise, set to 0 (in other words, only show the local user's voxel)
        finalOpacity = (currentName === voxelName) ? opacity : 0;
      }
    } else {
      // If emissivity is 0 or less, set opacity to 0
      finalOpacity = 0;
    }
  }
  // Assign the calculated opacity value to the corresponding instance
  opacityAttribute.array[instanceId] = finalOpacity; */
  opacityAttribute.needsUpdate = true;
  colorAttribute.needsUpdate = true;
  //emissivityAttribute.needsUpdate = true;
  info(`Updated instance ${instanceId} opacity to ${opacity} with emissivity ${emissivity}`);
}
/**
 * Look up recent voxel updates in VarvEngine based on timestamp
 * @param {number} recentTimestamp Timestamp to filter updates
 * @param {React.Ref} voxelInstancedMeshRef Reference to the voxel instanced mesh
 * @returns {Promise<number>} Number of updated voxels
 */
// voxelInstancedMeshRef is not used in this function yet, but it can be used to update opacities
async function getRecentVoxelUpdates(voxelRef, recentTimestamp, showVoxels) {
  //console.log("RECENT TIMESTAMP", recentTimestamp);
  try {
    const recentUpdates = await VarvEngine.lookupInstances(
      "VoxelStore",
      FilterAction.constructFilter({
        property: "lastSeen",
        greaterThan: recentTimestamp,
      })
    );
    if (!recentUpdates || recentUpdates.length === 0) {
      info("No new updates found since recentTimestamp");
      return 0;
    }
    let updatedCount = 0;
    for (const voxelUuid of recentUpdates) {
      const voxelConcept = await VarvEngine.getConceptFromUUID(voxelUuid);
      if (!voxelConcept) continue;
      const {name} = await getLocalUser();
      const username = voxelUuid.split("#")[0];
      const userColor = await getColorForUuid(voxelUuid);
      const attention = voxelConcept.getPropertyValue(voxelUuid, "attention");
      const distance = voxelConcept.getPropertyValue(voxelUuid, "distance");
      const lastSeen = voxelConcept.getPropertyValue(voxelUuid, "lastSeen");
      info(`User: ${username}, Voxel ID: ${voxelUuid}, Attention: ${attention}, Last Seen: ${lastSeen} Distance: ${distance}`);
      const instanceId = extractVoxelIndex(voxelUuid);
      const emissivity = await getVoxelEmissivity(voxelUuid, distance); // TODO: Should also access list of target ids.
      updateVoxelOpacity(voxelRef, instanceId, attention, userColor, emissivity, showVoxels, voxelUuid, name);
      // Check if instanceId is valid and within bounds before updating opacity
      info(`Will update opacity for instanceId here: ${instanceId}`);
      updatedCount++;
    }
    return updatedCount;
  } catch (error) {
    console.error("Error processing voxel updates:", error);
    return 0;
  }
}
export {
  getCurrentEnclosure,
  getLocalUser,
  getVoxelStoreID,
  getOrCreateVoxel,
  updateVoxelAttention,
  updateVoxelOpacity,
  getColorForUuid,
  getVoxelEmissivity,
  //loadVoxelAttentionValues,
  getRecentVoxelUpdates,
  extractVoxelIndex,
  clearAllLogsForLocalUser
  //SECONDS_TO_FULL_ATTENTION
};
const concept = "VoxelStore"
const variable = `${concept}Helpers`
// Delete a concept instance given a uuid
export const deleteOne = async (uuid) => {
 const concept = await VarvEngine.getConceptFromUUID(uuid);
 if (concept) {
   await concept.delete(uuid);
   info(`Deleted concept instance with UUID: ${uuid}`);
 }
};
// Delete all instances of the concept
export const deleteAll = async () => { 
    const instances = await VarvEngine.lookupInstances(concept); 
    instances.forEach(async (instance) => await deleteOne(instance))
}
if (globalThis[variable]) delete globalThis[variable];
globalThis[variable] = { deleteOne, deleteAll, clearAllLogsForLocalUser };
window.addEventListener('beforeunload', () => { delete globalThis[variable] });
// TODO LATER: Add updateVoxelOpacity function to update opacity of voxel in Voxel concept for a given voxelUuid
// TODO LATER: Add setVoxelAsTarget function to set isTarget property in Voxel concept for a given voxelUuid
// TODO LATER: Add updateVoxelColor function to update color if voxel has isTarget is true and distance is less than a threshold. Note to reset color if distance is greater than threshold.