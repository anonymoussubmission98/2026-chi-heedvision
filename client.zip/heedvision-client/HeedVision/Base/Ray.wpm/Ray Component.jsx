import React, { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useXR } from '@react-three/xr';
import { Raycaster, Vector3 } from 'three';
import { useGlobalEvents } from '#Spatialstrates .global-events';
// Debug settings
const DEBUG = false;
const log = (...args) => DEBUG && console.log('[Heedvision > RayCone]', ...args);
/**
 * RayCone component for detecting intersections with voxels
 * and triggering appropriate events.
 * @returns {JSX.Element} The ray cone component.
 */
function RayCone() {
    const coneRef = useRef();
    const frameCounter = useRef(0);
    const mode = useXR((state) => state.mode);
    const raycaster = useRef(new Raycaster());
    const { scene } = useThree();
    const { triggerEvent } = useGlobalEvents() || {};
    const direction = useRef(new Vector3());
    // Track the last intersection data
    const lastIntersectionRef = useRef({
        time: 0,
        instanceId: null,
        object: null,
        point: null
    });
    // Configure the raycaster
    useEffect(() => {
        log("Mounting RayCone component");
        // Optimize ray parameters
        raycaster.current.params.Line.threshold = 0.1;
        raycaster.current.near = 0.01;
        raycaster.current.far = 100;
        // Make the raycaster accessible globally for debugging
        window.sceneRaycaster = raycaster.current;
        return () => {
            log("Unmounting RayCone component");
            if (window.sceneRaycaster === raycaster.current) {
                window.sceneRaycaster = undefined;
            }
            if (lastIntersectionRef.current) {
                lastIntersectionRef.current.object = null;
                lastIntersectionRef.current.point = null;
            }
            raycaster.current = null;
        }
    }, []);
    // Debugging mode and scene
    useEffect(() => {
        if (DEBUG) {
            console.log(`[DEBUG] Ray: XR mode changed to: ${mode}`);
            // When entering XR mode, check if key resources are valid
            if (mode === 'immersive-ar' || mode === 'immersive-vr') {
                //console.log('[DEBUG] Entering XR mode, validating resources:');
                //console.log(`- Scene valid: ${!!scene}`);
                //console.log(`- Raycaster valid: ${!!raycaster.current}`);
                //console.log(`- XR Camera valid: ${!!window.moduleDeviceManager?.xrCamera}`);
                //console.log(`- Cone ref valid: ${!!coneRef.current}`);
            }
        }
    }, [mode, scene]);
    // Smooth camera following (runs every frame)
    useFrame(() => {
        // Get camera from window object
        if (!(window.moduleDeviceManager?.xrCamera || window.moduleDeviceManager?.camera) || 
            !coneRef.current) {
            return;
        }
        try {
            const camera = mode === 'immersive-ar' || mode === 'immersive-vr' 
                ? window.moduleDeviceManager?.xrCamera 
                : window.moduleDeviceManager?.camera;
            // Position the cone at the camera position
            coneRef.current.position.copy(camera.position);
            coneRef.current.quaternion.copy(camera.quaternion);
        } catch (e) {
            console.error("Error in RayCone camera following:", e);
        }
    });
    // Ray casting logic (skips frames to reduce load)
    useFrame(() => {
        frameCounter.current++;
        if (frameCounter.current % 30 !== 0) return; // Skip frames to reduce load
        /* if (DEBUG) {
            frameCounter.current++;
            if (frameCounter.current % 60 === 0) { // Log only every 60 frames to reduce noise
                console.log(`[DEBUG] Ray: Frame #${frameCounter.current}, XR mode: ${mode}`);
            }
        } */
        // Get camera from window object or three.js
        if (!(window.moduleDeviceManager?.xrCamera || window.moduleDeviceManager?.camera) || 
            !coneRef.current || !scene || !triggerEvent) {
            /* if (DEBUG && frameCounter.current % 60 === 0) {
                console.log("[DEBUG] Ray: Missing critical dependencies, skipping frame");
            } */
            return;
        }
        try {
            //const frameStart = performance.now();
            const camera = mode === 'immersive-ar' || mode === 'immersive-vr' 
                ? window.moduleDeviceManager?.xrCamera 
                : window.moduleDeviceManager?.camera;
            /* if (DEBUG && frameCounter.current % 120 === 0) {
                console.log(`[DEBUG] Ray: frame using camera type: ${mode}, valid: ${!!camera}`);
            } */
            // Set up raycaster from camera
            direction.current.set(0, 0, -1).applyQuaternion(camera.quaternion);
            raycaster.current.set(camera.position, direction.current);
            // Cast rays and find all intersections
            const intersects = raycaster.current.intersectObjects(scene.children, true);
            if (intersects.length > 0) {
                const now = Date.now();
                const instancedHits = intersects.filter(hit => 
                    hit.object.isInstancedMesh && 
                    hit.instanceId !== undefined
                );
                if (instancedHits.length > 0) {
                    const hit = instancedHits[0];
                    const instanceId = hit.instanceId;
                    //console.log("Picking closest instance ID", instanceId, "from", instancedHits.length, "hits");
                    if (lastIntersectionRef.current.instanceId !== instanceId) {
                        //console.log(lastIntersectionRef.current.instanceId, "!==", instanceId);
                        triggerEvent('voxel-intersection', {
                            instanceId: instanceId,
                            point: hit.point.toArray(),
                            distance: hit.distance,
                            timestamp: now
                        });
                        lastIntersectionRef.current.instanceId = instanceId;
                        lastIntersectionRef.current.time = now;
                    } else {
                        if (now - lastIntersectionRef.current.time > 500) {
                            //console.log("Significant time difference, for instance ID", instanceId, "time:", now - lastIntersectionRef.current.time);
                            triggerEvent('voxel-intersection', {
                                instanceId: instanceId,
                                point: hit.point.toArray(),
                                distance: hit.distance,
                                timestamp: now
                            });
                            lastIntersectionRef.current.time = now;
                        }
                    }
                }
                /**
                 * If previous ID is not equal to current ID {
                 *  1. Log current ID and trigger event
                 *  2. Previous ID = current ID
                 *  3. Previous timestamp = now
                 * } else {
                 *  1. If now - previous timestamp > 500ms {
                 *  2. Log current ID and trigger event
                 *  3. Previous timestamp = now
                 * }
                 */
                /*  // Check for instancedMesh intersections first
                // In new implementation, we check for instancedMesh without requiring userData.isVoxelMesh 
                if (instancedHits.length > 0) {
                    const hit = instancedHits[0]; // Use the closest hit
                    const instanceId = hit.instanceId;
                    // Only trigger events for new instances or significant time has passed
                    if (instanceId !== lastIntersectionRef.current.instanceId || 
                        now - lastIntersectionRef.current.time > 500) {
                        // Update the last intersection data
                        lastIntersectionRef.current = {
                            time: now,
                            instanceId: instanceId,
                            object: hit.object,
                            point: hit.point
                        };
                        // Detailed logging for debug
                        if (DEBUG) {
                            console.log(`Instanced Mesh Intersection:`, {
                                instanceId: instanceId,
                                object: hit.object.name || hit.object.uuid,
                                point: hit.point.toArray(),
                                distance: hit.distance
                            });
                        }
                        // Trigger event with the instance data
                        triggerEvent('voxel-intersection', {
                            instanceId: instanceId,
                            point: hit.point.toArray(),
                            distance: hit.distance,
                            timestamp: now
                        });
                    }
                } else {
                    // Handle regular (non-instanced) mesh intersections
                    // Note: Using 'contentLayer' userData type for regular objects
                    const contentHits = intersects.filter(hit => 
                        hit.object.userData && 
                        (hit.object.userData.type === 'contentLayer' || hit.object.type === 'Mesh')
                    );
                    if (contentHits.length > 0) {
                        const hit = contentHits[0];
                        // Only trigger for new objects or when time has passed
                        if (hit.object !== lastIntersectionRef.current.object || 
                            now - lastIntersectionRef.current.time > 200) {
                            // Update last intersection data
                            lastIntersectionRef.current = {
                                time: now,
                                instanceId: null,
                                object: hit.object,
                                point: hit.point
                            };
                            // Trigger a regular intersection event
                            triggerEvent('object-intersection', {
                                objectId: hit.object.uuid,
                                objectName: hit.object.name || 'unnamed',
                                point: hit.point.toArray(),
                                distance: hit.distance,
                                timestamp: now
                            });
                        }
                    }
                } */
            }
            /* if (DEBUG && frameCounter.current % 120 === 0) {
                console.log(`[DEBUG] Ray: frame completed in ${performance.now() - frameStart}ms`);
            } */
        } catch (e) {
            console.error("Error in RayCone useFrame:", e);
        }
    });
    return (
        <group ref={coneRef}>
            {/* This is an empty group that follows the camera */}
            {/* In a full implementation, you might want to add a visual indicator here */}
            <mesh position={[0, 0, -.5]} renderOrder={9999}>
                <circleGeometry args={[0.006, 32]} />
                <meshBasicMaterial color="white" opacity={0.5} transparent depthTest={false} depthWrite={false} />
            </mesh>
        </group>
    );
}
/**
 * Varv integration for the RayCone
 * @returns {JSX.Element} The RayCone component wrapped in Varv context.
 */
export function Main() {
    return <RayCone />;
}