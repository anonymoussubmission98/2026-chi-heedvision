//import * as THREE from "three";
import { Varv, useProperty } from "#VarvReact";
import React, {
  useRef,
  useState,
  useEffect,
  useMemo,
  useCallback,
} from "react";
import {
  initializeGeometry,
  calculateBoundaries,
  processVoxelChunk,
} from "#Enclosure .helpers";
import { VoxelMaterial } from "#Enclosure .utilities";
import { VoxelLayer } from "#VoxelLayer .default";
import { ModelLayer } from "#ModelLayer .default";
import { InfoLayer } from "#InfoLayer .default";
import { useGlobalEvents } from "#Spatialstrates .global-events";
import {
  getLocalUser,
  getVoxelStoreID,
  getOrCreateVoxel,
  updateVoxelAttention,
  getColorForUuid,
  updateVoxelOpacity,
  getVoxelEmissivity,
  getRecentVoxelUpdates, 
  MUTUAL_USER_COLOR,
  LOCAL_USER_COLOR,
  OTHER_USER_COLOR,
} from "#VoxelStore .helpers";
import { useLogging } from "#Experiment .logger";
import { extend } from "@react-three/fiber";
import { Text as DreiText, Billboard } from "@react-three/drei";
extend({ VoxelMaterial });
import { EXPERIMENT_CONFIG } from "#ExperimentConstants";
const DEBUG = EXPERIMENT_CONFIG.DEBUG;
const SHOW_VOXELS = EXPERIMENT_CONFIG.SHOW_VOXELS;
const { geometry, originalBoundingBox, bvh } = initializeGeometry();
/**
 * This Component renders within the Varv context.
 * @returns {JSX.Element}
 */
export function Main() {
  return (
    <Varv concept="Enclosure">
      <Enclosure />
    </Varv>
  );
}
const TextButton = ({
  boxColor = '#3498db',
  textColor = '#ffffff',
  width = 1,
  height = 0.3,
  depth = 0.1,
  fontSize = 0.15,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  ...props
}) => {
  return (
    <group position={position} rotation={rotation} {...props}>
      {/* Box background */}
      <mesh>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color={boxColor} />
      </mesh>
      {/* Text */}
      <DreiText
        position={[0, 0, depth / 2 + 0.01]}
        fontSize={fontSize}
        color={textColor}
        anchorX="center"
        anchorY="middle"
      >
        {props.children}
      </DreiText>
    </group>
  );
};
function UserLegend({userData}) {
  const { local, other } = userData;
  return (
    <group position={[0.025,0.5,1.8]}>
      <TextButton position={[-1.125, -2, 0]} boxColor={LOCAL_USER_COLOR}>{local.name}</TextButton>
      <TextButton position={[0, -2, 0]} boxColor={MUTUAL_USER_COLOR}>{"Shared"}</TextButton>
      <TextButton position={[1.125, -2, 0]} boxColor={OTHER_USER_COLOR}>{other.name}</TextButton>
    </group>
  )
}
/**
 * This component voxelizes a 3D geometry and revisualizes
 * attention by mapping it to corresponding voxel opacities.
 * @returns {JSX.Element}
 */
function Enclosure() {
  const voxelSize = 0.1;
  const modelRef = useRef();
  const voxelMaterialRef = useRef();
  const voxelInstancedMeshRef = useRef();
  const processingRef = useRef(false);
  const chunkSizeRef = useRef(1000);
  const voxelGenerationRef = useRef(null);
  const [enclosureName] = useProperty("name");
  const [localUser] = useProperty("user");
  const [localUserName] = useProperty("username");
  const [lastIntersectedInstanceId, setLastIntersectedInstanceId] = useState(null);
  const [lastIntersectedDistance, setLastIntersectedDistance] = useState(null);
  const [emissivity, setEmissivity] = useState(0);
  const [userData, setUserData] = useState(null);
  const [voxelCount, setVoxelCount] = useState(0);
  const [showVoxels, setShowVoxels] = useState(SHOW_VOXELS);
  const [voxelPositions, setVoxelPositions] = useState([]);
  const [processingStatus, setProcessingStatus] = useState("");
  const [recentTimestamp, setRecentTimestamp] = useState(0);
  const [triggerTimestamp, setTriggerTimestamp] = useState(0);
  const { logAndCommitNow } = useLogging(localUserName, enclosureName);
  const [experimentStart, setExperimentStart] = useState(0);
  const [targetIds, setTargetIds] = useState([]);
  const globalEvents = useGlobalEvents() || {};
  const boundaries = useMemo(
    () => calculateBoundaries(originalBoundingBox, voxelSize),
    [voxelSize]
  );
  useEffect(() => {
    if (!localUserName || !enclosureName) {
      console.warn("Missing localUserName or enclosureName");
      return;
    }
    // Handler for experiment start
    const handleExperimentStart = (event) => {
      const { timestamp, user, enclosure } = event.detail;
      console.log(`[Enclosure] Experiment started by ${user} in ${enclosure} at ${timestamp}`);
      logAndCommitNow("start-experiment", {
        experimentType: EXPERIMENT_CONFIG.TYPE,
        voxelCount: voxelCount,
        targetCount: targetIds.length,
        targetIds: targetIds,
        experimentStartMs: timestamp,
        experimentEndMs: null,
        durationMs: null
      })
      setExperimentStart(timestamp);
      setRecentTimestamp(0);
      setTriggerTimestamp(Date.now());

    };
    // Handler for experiment end
    const handleExperimentEnd = (event) => {
      if (!experimentStart) {
        console.warn("No experiment started yet to end");
        return;
      }
      const { timestamp, user, enclosure } = event.detail;
      console.log(`[Enclosure] Experiment ended by ${user} in ${enclosure} after ${timestamp - experimentStart}ms`);
      logAndCommitNow("end-experiment", {
        experimentType: EXPERIMENT_CONFIG.TYPE,
        voxelCount: voxelCount,
        targetCount: targetIds.length,
        targetIds: targetIds,
        experimentStartMs: experimentStart,
        experimentEndMs: timestamp,
        durationMs: timestamp - experimentStart
      })
      setRecentTimestamp(0);
      setTriggerTimestamp(Date.now());
    };
    // Subscribe to events
    document.addEventListener('experiment-start', handleExperimentStart);
    document.addEventListener('experiment-end', handleExperimentEnd);
    // Clean up when component unmounts
    return () => {
      document.removeEventListener('experiment-start', handleExperimentStart);
      document.removeEventListener('experiment-end', handleExperimentEnd);
    };
  }, [localUserName, enclosureName, experimentStart]);
  useEffect(() => {
    async function fetchUserData() {
      let userData = {}
      userData["local"] = { uuid: localUser, name: localUserName };
      const users = await VarvEngine.lookupInstances("User");
      const otherUser = users.find(user => user !== localUser);
      const otherUserConcept = await VarvEngine.getConceptFromUUID(otherUser)
      const otherUserName = otherUserConcept?.getPropertyValue(otherUser, "name");
      userData["other"] = { uuid: otherUser, name: otherUserName };
      setUserData(userData);
      console.log("User data fetched:", userData);
       if (triggerTimestamp !== 0) {
        setRecentTimestamp(0);
        setTriggerTimestamp(Date.now());
        logAndCommitNow("change-user", {
          userData: userData
        });
      }
    }
    fetchUserData();
  }, [localUser]);
 useEffect(() => {
    const handleVoxelIntersection = async (event) => {
      const {name} = await getLocalUser();
      if (event.instanceId !== undefined) {
        try {
          if (lastIntersectedInstanceId !== event.instanceId) {
            setLastIntersectedInstanceId(event.instanceId);
          }
          if (lastIntersectedDistance !== event.distance) {
            setLastIntersectedDistance(event.distance);
          }
          console.log("handleVoxelIntersection", name)
          const voxelUuid = await getVoxelStoreID(event.instanceId);
          console.log("Voxel UUID:", voxelUuid);
          const voxelConcept = await getOrCreateVoxel(voxelUuid);
          const userColor = await getColorForUuid(voxelUuid);
          const newAttention = await updateVoxelAttention(voxelUuid, voxelConcept, event.distance, targetIds);
          const emissivity = await getVoxelEmissivity(voxelUuid, event.distance); // TODO: Should also access list of target ids.
          if (voxelInstancedMeshRef.current) {
            updateVoxelOpacity(voxelInstancedMeshRef, event.instanceId, newAttention, userColor, emissivity, showVoxels, voxelUuid, name);
          }
          if (Math.abs(event.timestamp - recentTimestamp) > 2000) {
            setTriggerTimestamp(event.timestamp);
          }
        }
        catch (error) {
          console.error("Error processing voxel intersection:", error);
        }
      }
    };
    const unsubscribe = globalEvents.subscribeEvent(
      "voxel-intersection",
      handleVoxelIntersection
    );
    return () => {
      if (typeof unsubscribe === "function") {
        unsubscribe();
      }
    };
  }, [targetIds]);
  useEffect(() => {
    if (!triggerTimestamp || triggerTimestamp === recentTimestamp) return;
    async function processUpdates() {
      try {
        const updatedCount = await getRecentVoxelUpdates(voxelInstancedMeshRef, recentTimestamp, showVoxels);
        setRecentTimestamp(triggerTimestamp);
      } catch (error) {
        console.error("Error processing voxel updates:", error);
      }
    }
    processUpdates();
  }, [triggerTimestamp]);
  useEffect(() => {
    return () => {
      if (voxelGenerationRef.current) {
        cancelAnimationFrame(voxelGenerationRef.current);
      }
    };
  }, []);
  const processVoxelsInChunks = useCallback(() => {
    if (
      processingRef.current ||
      !modelRef.current ||
      !voxelInstancedMeshRef.current
    )
      return;
    console.time("Voxel Generation");
    processingRef.current = true;
    let currentState = {
      i: 0,
      j: 0,
      k: 0,
      processedCount: 0,
      positions: [],
    };
    const processChunk = () => {
      const result = processVoxelChunk(
        boundaries,
        voxelSize,
        bvh,
        currentState,
        chunkSizeRef.current
      );
      currentState = result.state;
      setProcessingStatus(
        `Processing: ${result.progress}% (${result.voxelCount} voxels found)`
      );
      if (!result.isComplete) {
        voxelGenerationRef.current = requestAnimationFrame(processChunk);
      } else {
        processingRef.current = false;
        console.timeEnd("Voxel Generation");
        setVoxelCount(result.voxelCount);
        setVoxelPositions(result.state.positions);
        // Check if Targets concept exists in the Varv engine
        async function checkOrCreateTargets() {
          const targetsConcept = await VarvEngine.getConceptFromUUID("target-data");
          if (!targetsConcept) {
            console.log("Targets does not exist, populating a new one");
            const randomIndexes = [];
            const randomCount = 0.05 * result.state.positions.length;
            const totalVoxels = result.state.positions.length;
            for (let i = 0; i < randomCount; i++) {
              const randomIndex = Math.floor(Math.random() * totalVoxels);
              if (!randomIndexes.includes(randomIndex)) {
                randomIndexes.push(randomIndex);
              }
            }
            await VarvEngine.getConceptFromType("Targets").create("target-data", {
              data: randomIndexes
            });
            setTargetIds(randomIndexes);
            console.log("Targets created successfully");
            console.log("Target IDs:", targetIds.length);
          } else {
            const fetchedTargetIds = targetsConcept.getPropertyValue("target-data", "data"); 
            setTargetIds(fetchedTargetIds);
            console.log("Targets already exist, fetched successfully");
            console.log("Target IDs:", fetchedTargetIds.length);
          }
        }
        checkOrCreateTargets();
        setProcessingStatus("");
      }
    };
    voxelGenerationRef.current = requestAnimationFrame(processChunk);
  }, [boundaries, voxelSize, targetIds]);
  useEffect(() => {
    if (
      !processingRef.current &&
      modelRef.current &&
      voxelInstancedMeshRef.current &&
      voxelPositions.length === 0
    ) {
      processVoxelsInChunks();
    }
  }, [
    modelRef.current,
    voxelInstancedMeshRef.current,
    voxelPositions.length,
    processVoxelsInChunks,
  ]);/* 
  useEffect(() => {
    if (voxelInstancedMeshRef.current && voxelPositions.length > 0) {
      voxelInstancedMeshRef.current.userData.isVoxelMesh = true;
    }
  }, [voxelPositions]); */
  useEffect(() => {
    if (voxelMaterialRef.current) {
      voxelMaterialRef.current.uniforms.baseOpacity.value = showVoxels
        ? 1.0
        : 1.0;
    }
  }, [showVoxels]);
  const handlePointerDown = () => {
    //console.log("Clicked", showVoxels);
    if (SHOW_VOXELS) {
    const newVisibility = !showVoxels;
      setShowVoxels(newVisibility);
      setRecentTimestamp(0);
      setTriggerTimestamp(Date.now());
      logAndCommitNow("toggle-voxel-visibility", {
        visible: newVisibility
      });
    }
  };
  return (<>
    {/* <AxesLayer 
        length={3.6}                  
        tickInterval={0.3}            
        tickSize={0.06}                
        offset={[-1.75, -1.4, -10]}   
        showTicks={true}              
        showLabels={true}             
        thickness={0.02}              
        coneSize={0.08}            
      /> */}
    <group scale={[0.15, 0.15, 0.15]} position={[0, 1.5, 0]}>
      <ModelLayer
        refers={modelRef}
        geometry={geometry}
        onPointerDown={handlePointerDown}
      />
      <VoxelLayer
        refers={voxelInstancedMeshRef}
        voxelSize={voxelSize}
        materialRef={voxelMaterialRef}
        voxelPositions={voxelPositions}
        visible={showVoxels}
      />
      {SHOW_VOXELS && userData && <UserLegend userData={userData} />}
      <InfoLayer show={true}>
        {processingStatus ? (
          <p>{processingStatus}</p>
        ) : (
          <div style="width: 20px; height: 20px; background-color:'orange';">{SHOW_VOXELS ? "Click to Toggle Voxels" : "Targets ready for observation"}</div>
        )}
        {SHOW_VOXELS && <p>
          Visible: {processingStatus ? "Loading..." : showVoxels ? "Yes" : "No"}
        </p>}
        {DEBUG && <p>Count: {processingStatus ? "Loading..." : voxelCount}</p>}
        {DEBUG && <p>Status: {processingStatus ? "Loading..." : (recentTimestamp === triggerTimestamp) ? "Synced" : "Syncing..."}</p>}
        {DEBUG && <p>Last Intersected {lastIntersectedInstanceId} at distance: {lastIntersectedDistance}, emissivity: {emissivity}</p>}
      </InfoLayer>
    </group>   
    </>
  );
}
function AxesLayer({ 
  length = 5,           
  tickInterval = 1,     
  tickSize = 0.2,       
  offset = [0, 0, 0],   
  showTicks = true,     
  showLabels = true,    
  thickness = 0.03,     
  coneSize = 0.08       
}) {
  const colors = {
    x: 'white',
    y: 'white',
    z: 'white'
  };
  const createAxis = (axis) => {
    const config = {
      x: {
        cylinderPosition: [length/2, 0, 0],
        cylinderRotation: [0, 0, Math.PI/2],
        conePosition: [length + tickSize + 0.1, 0, 0],
        coneRotation: [0, 0, -Math.PI/2],
        labelPosition: [length + 0.3, 0, 0],
        tickRotation: [0, 0, 0],
        tickLabelOffset: [0, -tickSize/2 - 0.2, 0],
        tickLabelRotation: [0, 0, 0]
      },
      y: {
        cylinderPosition: [0, length/2, 0],
        cylinderRotation: [0, 0, 0],
        conePosition: [0, length + tickSize + 0.1, 0],
        coneRotation: [0, 0, 0],
        labelPosition: [0, length + 0.3, 0],
        tickRotation: [0, 0, Math.PI/2],
        tickLabelOffset: [-tickSize/2 - 0.2, 0, 0],
        tickLabelRotation: [0, 0, 0]
      },
      z: {
        cylinderPosition: [0, 0, length/2],
        cylinderRotation: [Math.PI/2, 0, 0],
        conePosition: [0, 0, length  + tickSize + 0.1],
        coneRotation: [Math.PI/2, 0, 0],
        labelPosition: [0, 0, length + 0.3],
        tickRotation: [0, Math.PI/2, 0],
        tickLabelOffset: [0, -tickSize/2 - 0.2, 0],
        tickLabelRotation: [0, 0, 0]
      }
    };
    const axisConfig = config[axis];
    const ticks = showTicks ? Array.from(
      { length: Math.floor(length / tickInterval) }, 
      (_, i) => {
        const pos = (i + 1) * tickInterval;
        const tickPosition = {
          x: axis === 'x' ? pos : 0,
          y: axis === 'y' ? pos : 0,
          z: axis === 'z' ? pos : 0
        };
        return (
          <group key={`${axis}-tick-${i}`} raycast={() => null} name={`${axis}-tick`}>
            <mesh 
              name={`${axis}-tick-${i}`}
              position={[tickPosition.x, tickPosition.y, tickPosition.z]} 
              rotation={axisConfig.tickRotation}
              raycast={() => null}
            >
              <sphereGeometry args={[tickSize]} />
              <meshStandardMaterial color={colors[axis]} />
            </mesh>
            {showLabels && (
              <group
                name={`${axis}-tick-label-${i}`}
                position={[
                  tickPosition.x + axisConfig.tickLabelOffset[0], 
                  tickPosition.y + axisConfig.tickLabelOffset[1], 
                  tickPosition.z + axisConfig.tickLabelOffset[2]
                ]}
              >
                <Billboard
                  follow={true}
                  lockX={false}
                  lockY={false}
                  lockZ={false}
                >
                  <DreiText 
                    fontSize={0.15} 
                    color={"black"}
                    rotation={axisConfig.tickLabelRotation}
                  >
                    {pos.toFixed(1)}
                  </DreiText>
                </Billboard>
              </group>
            )}
          </group>
        );
      }
    ) : null;
    return (
      <group key={`${axis}-axis`} name={`${axis}-axis`}>
        <mesh 
          name={`${axis}-cylinder`}
          position={axisConfig.cylinderPosition} 
          rotation={axisConfig.cylinderRotation}
          raycast={() => null}
        >
          <cylinderGeometry args={[thickness, thickness, length, 12]} />
          <meshStandardMaterial color={colors[axis]} />
        </mesh>
        <mesh 
          position={axisConfig.conePosition} 
          rotation={axisConfig.coneRotation}
          raycast={() => null}
        >
          <coneGeometry args={[coneSize, coneSize * 2.5, 12]} />
          <meshStandardMaterial color={colors[axis]} />
        </mesh>
        {showLabels && (
          <group position={axisConfig.labelPosition}>
            <DreiText 
              fontSize={0.2} 
              color={"black"}
              fontWeight={700}
            >
              {axis.toUpperCase()}
            </DreiText>
          </group>
        )}
        {ticks}
      </group>
    );
  };
  return (
    <group position={offset} raycast={() => null} name="AxesLayer">
      {createAxis('x')}
      {createAxis('y')}
      {createAxis('z')}
    </group>
  );
}