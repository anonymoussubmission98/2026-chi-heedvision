import * as THREE from "three";
import { MeshBVH } from "three-mesh-bvh";
import { EXPERIMENT_CONFIG } from "#ExperimentConstants";
const GEOMETRY_NAME = EXPERIMENT_CONFIG.GEOMETRY_NAME;
/**
 * Initializes and returns the geometry and BVH for voxelization
 */
export function initializeGeometry() {
  const geometry = Geometry.createGeometry(GEOMETRY_NAME);
  const originalBoundingBox = new THREE.Box3();
  geometry.computeBoundingBox();
  originalBoundingBox.copy(geometry.boundingBox);
  const bvhGeometry = geometry.clone();
  const bvh = new MeshBVH(bvhGeometry, { maxLeafTris: 2, strategy: 0 });
  return { geometry, originalBoundingBox, bvh };
}
/**
 * Calculates the boundaries for voxelization
 * @param {THREE.Box3} originalBoundingBox The original bounding box
 * @param {number} voxelSize The size of each voxel
 * @returns {Object} Boundaries object with min, max, paddedSize, steps
 */
export function calculateBoundaries(originalBoundingBox, voxelSize) {
  const padding = voxelSize * 0.5;
  const size = new THREE.Vector3();
  originalBoundingBox.getSize(size);
  const min = new THREE.Vector3(
    originalBoundingBox.min.x - size.x * padding,
    originalBoundingBox.min.y - size.y * padding,
    originalBoundingBox.min.z - size.z * padding
  );
  const max = new THREE.Vector3(
    originalBoundingBox.max.x + size.x * padding,
    originalBoundingBox.max.y + size.y * padding,
    originalBoundingBox.max.z + size.z * padding
  );
  const paddedSize = new THREE.Vector3();
  paddedSize.subVectors(max, min);
  const stepsX = Math.ceil(paddedSize.x / voxelSize);
  const stepsY = Math.ceil(paddedSize.y / voxelSize);
  const stepsZ = Math.ceil(paddedSize.z / voxelSize);
  return { min, max, paddedSize, stepsX, stepsY, stepsZ };
}
/**
 * Processes a chunk of voxels
 * @param {Object} boundaries The boundaries object
 * @param {number} voxelSize The size of each voxel
 * @param {MeshBVH} bvh The BVH instance
 * @param {Object} currentState Current processing state
 * @param {number} chunkSize Number of voxels to process in this chunk
 * @returns {Object} Updated state and processing information
 */
export function processVoxelChunk(
  boundaries,
  voxelSize,
  bvh,
  currentState,
  chunkSize
) {
  const { min, stepsX, stepsY, stepsZ } = boundaries;
  const { i, j, k, processedCount, positions } = currentState;
  const half = voxelSize * 0.5;
  const voxelBox = new THREE.Box3();
  const invMatrix = new THREE.Matrix4();
  let newI = i,
    newJ = j,
    newK = k;
  let newProcessedCount = processedCount;
  let chunkCount = 0;
  const newPositions = [...positions];
  const totalVoxels = stepsX * stepsY * stepsZ;
  while (chunkCount < chunkSize && newI < stepsX) {
    while (chunkCount < chunkSize && newJ < stepsY) {
      while (chunkCount < chunkSize && newK < stepsZ) {
        const x = min.x + (newI + 0.5) * voxelSize;
        const y = min.y + (newJ + 0.5) * voxelSize;
        const z = min.z + (newK + 0.5) * voxelSize;
        voxelBox.min.set(x - half, y - half, z - half);
        voxelBox.max.set(x + half, y + half, z + half);
        if (bvh.intersectsBox(voxelBox, invMatrix)) {
          newPositions.push([x, y, z]);
        }
        newK++;
        chunkCount++;
        newProcessedCount++;
      }
      if (newK >= stepsZ) {
        newK = 0;
        newJ++;
      } else {
        break;
      }
    }
    if (newJ >= stepsY) {
      newJ = 0;
      newI++;
    } else {
      break;
    }
  }
  const progress = Math.round((newProcessedCount / totalVoxels) * 100);
  const isComplete = newI >= stepsX;
  return {
    state: {
      i: newI,
      j: newJ,
      k: newK,
      processedCount: newProcessedCount,
      positions: newPositions,
    },
    progress,
    voxelCount: newPositions.length,
    isComplete,
  };
}