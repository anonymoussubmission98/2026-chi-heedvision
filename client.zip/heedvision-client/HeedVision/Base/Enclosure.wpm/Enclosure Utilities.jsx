import * as THREE from 'three';
export class VoxelMaterial extends THREE.ShaderMaterial {
  constructor() {
    super({
      uniforms: {
        baseOpacity: { value: 1.0 }
      },
      vertexShader: `
        attribute vec3 instanceColor;
        attribute float instanceOpacity;
        attribute float instanceEmissive;
        varying vec3 vColor;
        varying float vOpacity;
        varying float vEmissive;
        void main() {
          vColor = instanceColor;
          vOpacity = instanceOpacity;
          vEmissive = instanceEmissive;
          vec3 transformed = position;
          vec4 mvPosition = modelViewMatrix * instanceMatrix * vec4(transformed, 1.0);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        uniform float baseOpacity;
        varying vec3 vColor;
        varying float vOpacity;
        varying float vEmissive; 
        void main() {
          vec3 finalColor = vColor * (1.0 + vEmissive);
          gl_FragColor = vec4(finalColor, vOpacity * baseOpacity);
        }
      `,
      transparent: true,
    });
  }
}