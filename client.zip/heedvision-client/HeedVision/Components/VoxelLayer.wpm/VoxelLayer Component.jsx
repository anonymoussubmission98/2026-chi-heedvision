import * as THREE from "three";
import React, { useState, useEffect } from "react";
/**
 * This component renders a voxel layer in the 3D scene.
 * It uses instanced mesh to efficiently render multiple voxels.
 * @param {Object} props The props for the VoxelLayer component.
 * @param {React.Ref} props.refers The reference to the instanced mesh.
 * @param {React.Ref} props.materialRef The reference to the voxel material.
 * @param {number} props.voxelSize The size of each voxel.
 * @param {Array} props.voxelPositions The positions of the voxels.
 * @param {boolean} props.visible Flag to control visibility of the layer.
 * @returns {JSX.Element} The rendered voxel layer.
 */
export function VoxelLayer({
  refers,
  materialRef,
  voxelSize,
  voxelPositions,
  visible
}) {
  const [voxelGeometry] = useState(() => {
    const geometry = new THREE.BoxGeometry(voxelSize, voxelSize, voxelSize);
    return geometry;
  });
  useEffect(() => {
    const mesh = refers.current;
    if (!mesh || voxelPositions.length === 0) return;
    const colors = new Float32Array(voxelPositions.length * 3);
    const opacities = new Float32Array(voxelPositions.length);
    const emissives = new Float32Array(voxelPositions.length); 
    const tempObject = new THREE.Object3D();
    const color = new THREE.Color();
    for (let i = 0; i < voxelPositions.length; i++) {
      tempObject.position.set(...voxelPositions[i]);
      tempObject.updateMatrix();
      mesh.setMatrixAt(i, tempObject.matrix);
      color.setHSL(0.7,0.5,0.5);
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
      opacities[i] = 0;
      emissives[i] = 0;
    }
    voxelGeometry.setAttribute(
      "instanceColor",
      new THREE.InstancedBufferAttribute(colors, 3)
    );
    voxelGeometry.setAttribute(
      "instanceOpacity",
      new THREE.InstancedBufferAttribute(opacities, 1)
    );
    voxelGeometry.setAttribute(
      "instanceEmissive",
      new THREE.InstancedBufferAttribute(emissives, 1)
    );
    mesh.instanceMatrix.needsUpdate = true;
  }, [voxelPositions, visible]);
  return (
    <instancedMesh
      ref={refers}
      name="VoxelLayer"
      args={[voxelGeometry, null, voxelPositions.length]}
      visible={true}
    >
      <voxelMaterial ref={materialRef} />
    </instancedMesh>
  );
}