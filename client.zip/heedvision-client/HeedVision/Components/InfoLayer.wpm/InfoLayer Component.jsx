import React from "react";
import { Text } from "@react-three/drei";
/**
 * This component renders a text layer in the 3D scene.
 * It displays information or instructions to the user.
 * The text is positioned above the center of the scene.
 * @param {Object} props The props for the InfoLayer component.
 * @param {React.ReactNode} props.children The text or elements to display.
 * @param {boolean} [props.show=true] Flag to control visibility of the layer.
 * @returns {JSX.Element|null} The rendered text layer or null if not visible.
 */
export function InfoLayer({ children, show = true }) {
  if (!show) return null;
  return (
    <group name="InfoLayerGroup">
      {React.Children.map(children, (child, index) => {
        if (React.isValidElement(child)) {
          return (
            <Text
              key={index}
              name="InfoLayerText"
              position={[0, 2.5 - index * 0.2, 0]}
              fontSize={0.125}
              color="black"
              anchorX="center"
              anchorY="middle"
            >
              {child.props.children}
            </Text>
          );
        } else {
          return null;
        }
      })}
    </group>
  );
}
