import React from "react";
import * as THREE from "three";
/**
 * This component renders a model layer in the 3D scene.
 * It uses a mesh with a standard material to represent the model.
 * The mesh is double-sided and has a specific color and shading properties.
 * @param {Object} props The props for the ModelLayer component.
 * @param {React.Ref} props.refers The reference to the mesh object.
 * @param {THREE.BufferGeometry} props.geometry The geometry for the mesh.
 * @param {function} props.onPointerDown The function to call on pointer down event.
 * @returns {JSX.Element} The rendered model layer.
 */
export function ModelLayer({ refers, geometry, onPointerDown }) {
  return (
    <mesh name="ModelLayer" ref={refers} geometry={geometry} onPointerDown={onPointerDown}>
      <meshStandardMaterial
        color="#52286a"
        metalness={0.1}
        roughness={0.2}
        envMapIntensity={0.5}
        flatShading={true}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}
